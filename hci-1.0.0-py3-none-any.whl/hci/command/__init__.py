from .command_packet import CommandPacket
from .commands import *
from .autocast import _autocast
