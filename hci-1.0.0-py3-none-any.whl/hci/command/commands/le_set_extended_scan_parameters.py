from ..command_packet import CommandPacket
from struct import pack, unpack

class HCI_LE_Set_Extended_Scan_Parameters(CommandPacket):
    def __init__(self):
        # TODO generate cmd
        super().__init__()

    def __str__(self):
        return super().__str__()


