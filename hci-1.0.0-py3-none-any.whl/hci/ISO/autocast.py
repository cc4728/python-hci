def _autocast(pkt):
    return pkt
